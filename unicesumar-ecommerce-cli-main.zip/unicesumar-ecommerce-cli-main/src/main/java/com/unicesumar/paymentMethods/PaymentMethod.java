package com.unicesumar.paymentMethods;

public interface PaymentMethod {
    public void pay(double amount);
}