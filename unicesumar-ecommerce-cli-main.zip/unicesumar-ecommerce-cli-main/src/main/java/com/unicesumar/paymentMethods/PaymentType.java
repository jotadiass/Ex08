package com.unicesumar.paymentMethods;

public enum PaymentType {
    PIX, BOLETO, CARTAO;
}